#include<stdio.h>
int main()
{
 int x=1;
 
 for(x=1; x<=10; x++)
    printf("\n%d",x);

 return 0;
}