#include<stdio.h>
void main()
{
 int a,b,sum;
 printf("Enter Numbers a and b : ");
 scanf("%d %d",&a,&b);
 sum=a+b;
 printf("\n%d + %d = %d",a,b,sum);
}
