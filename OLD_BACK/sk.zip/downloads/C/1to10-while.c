#include<stdio.h>

void main()
{
 int x=1;
 while(x<=10)
 {
   printf("\n%d",x);
   x++;
 }
}