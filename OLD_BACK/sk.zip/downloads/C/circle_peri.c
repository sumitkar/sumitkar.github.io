#include<stdio.h>

void main()
{
    int r;
    float pi=3.14;
    r=7;
    printf("Perimeter=%f",2*pi*r);
}