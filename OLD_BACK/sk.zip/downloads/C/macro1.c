#include<stdio.h>
#define pi 3.14

void main()
{
    int r;
    r=7;
    printf("Perimeter=%f",2*pi*r);
}